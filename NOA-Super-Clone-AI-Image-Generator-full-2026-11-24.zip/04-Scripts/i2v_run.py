#!/data/data/com.termux/files/usr/bin/python3
"""Image to Video в клоне Unlimited AI через интерфейс (uiautomator + input). Запуск от root:
  env LD_LIBRARY_PATH=$PREFIX/lib python3 i2v_run.py КАРТИНКА "описание движения (латиница)" [--dry-run] [--out DIR] [--app-inf FILE] [--clone-name NAME]
Правила человека (23.11): только в пределах счётчика «N/10»; при остатке 0 закрыть приложение;
перед генерацией войти как гость («Continue as Guest»). Прогресс: PROGRESS n% / FAIL / DONE путь.
--dry-run: дойти до кнопки Generate Video, не нажимая её. Коды выхода: 0 ok, 1 сбой, 3 лимит 0."""
import os, re, shutil, subprocess, sys, time, json
from pathlib import Path
import xml.etree.ElementTree as ET

PKG = "com.technosub.unlimitedaiimagen"
ACT = PKG + "/.MainActivity"
DUMP = "/data/local/tmp/i2v_ui.xml"
STAGE = "/storage/emulated/0/Pictures/i2v"
RETRIES = 3
APP_INF = Path(__file__).with_name("app.inf")
SUPER = "com.polestar.super.clone"


def adb(*args, timeout=40):
    """ADB must be connected to the Samsung on which the clone runs."""
    if not shutil.which("adb"):
        raise RuntimeError("adb не найден: запуск клона требует ADB-подключения к Samsung")
    p = subprocess.run(["adb", *args], capture_output=True, text=True, timeout=timeout)
    if p.returncode:
        raise RuntimeError("adb: " + (p.stderr.strip() or p.stdout.strip()))
    return p.stdout


def read_clone(path, name=None):
    """Read most recent identified clone, optionally matching its name."""
    if not path.is_file():
        raise RuntimeError(f"Нет {path}. Сначала запусти create_clone.py")
    records = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            rec = json.loads(line)
        except json.JSONDecodeError as e:
            raise RuntimeError(f"{path}:{number}: неверный JSON: {e}")
        if rec.get("original_package") != PKG or rec.get("host_package") != SUPER:
            continue
        if name and rec.get("clone_name") != name:
            continue
        if rec.get("task_status") == "identified" and isinstance(rec.get("task_id"), int) and rec.get("stub_activity"):
            records.append(rec)
    if not records:
        raise RuntimeError("В app.inf нет подходящего клона с определённым Task ID")
    return records[-1]


def focus_clone(rec):
    """Verify the recorded task is still the same clone before focusing it."""
    state = adb("shell", "dumpsys", "activity", "activities")
    activity = re.escape(SUPER + "/" + rec["stub_activity"])
    task = str(rec["task_id"])
    pattern = activity + r"\s+t" + re.escape(task) + r"\b"
    if not re.search(pattern, state):
        raise RuntimeError(
            f"Задача {task} ({rec['clone_name']}) больше не найдена. "
            "Task ID мог измениться; обнови запись app.inf после запуска клона."
        )
    adb("shell", "am", "task", "focus", task)
    time.sleep(3)
    focused = adb("shell", "dumpsys", "activity", "activities")
    top = re.search(r"topResumedActivity=[^\n]+", focused)
    if not top or not re.search(pattern, top.group(0)):
        raise RuntimeError("Не удалось подтвердить переключение на нужный клон")
    log("Клон:", rec["clone_name"], "Task ID:", task)


def _env():
    # app_process-утилиты (uiautomator, content) молча падают без окружения zygote
    env = {"PATH": "/system/bin"}
    z = subprocess.run(["/system/bin/pidof", "zygote64"], capture_output=True, text=True).stdout.split()
    if z:
        for kv in open(f"/proc/{z[0]}/environ", "rb").read().split(b"\0"):
            k, _, v = kv.decode(errors="ignore").partition("=")
            if k.startswith("ANDROID_") or k in ("BOOTCLASSPATH", "DEX2OATBOOTCLASSPATH",
                                                 "SYSTEMSERVERCLASSPATH", "EXTERNAL_STORAGE"):
                env[k] = v
    return env
ENV = _env()

def log(*a): print(time.strftime("%H:%M:%S"), *a, flush=True)
def sh(*cmd, t=60): return subprocess.run(cmd, capture_output=True, text=True, env=ENV, timeout=t).stdout

def dump():
    for _ in range(3):
        if os.path.exists(DUMP): os.remove(DUMP)
        sh("uiautomator", "dump", DUMP)
        if os.path.exists(DUMP):
            nodes = []
            for n in ET.parse(DUMP).iter("node"):
                b = [int(x) for x in re.findall(r"\d+", n.get("bounds", ""))]
                if len(b) == 4:
                    nodes.append(dict(text=n.get("text", ""), desc=n.get("content-desc", ""),
                                      cls=n.get("class", ""), pkg=n.get("package", ""),
                                      x=(b[0] + b[2]) // 2, y=(b[1] + b[3]) // 2, b=b))
            return nodes
        time.sleep(1)
    raise RuntimeError("uiautomator dump не удался")

def find(nodes, rx, key="text"):
    r = re.compile(rx)
    return next((n for n in nodes if r.search(n[key])), None)

def tap(n, pause=2.0): sh("input", "tap", str(n["x"]), str(n["y"])); time.sleep(pause)
def swipe_up(): sh("input", "swipe", "720", "2500", "720", "1100", "400"); time.sleep(1.2)

def counter(nodes):
    n = find(nodes, r"^\d+/\d+$")
    return int(n["text"].split("/")[0]) if n else None

def close_app(why):
    log("ОСТАНАВЛИВАЮ работу с клоном:", why)  # Не force-stop: это другой пакет / другие клоны

def open_i2v(clone):
    """Довести приложение до экрана Image to Video (с входом гостем)."""
    sh("input", "keyevent", "KEYCODE_WAKEUP"); sh("wm", "dismiss-keyguard"); time.sleep(1)
    focus_clone(clone)  # Не запускать оригинальный пакет через am start
    for _ in range(12):
        nodes = dump()
        if find(nodes, r"^Describe the motion$") or find(nodes, r"^Generate Video$"):
            return nodes
        g = find(nodes, r"Continue as Guest")
        if g: log("вход: Continue as Guest"); tap(g, 4); continue
        c = find(nodes, r"^Image to Video$")
        if c: log("меню: Image to Video"); tap(c, 3); continue
        if find(nodes, r"^Sign in$|Google sign-in"): swipe_up(); continue  # экран входа: гость ниже
        time.sleep(2)
    raise RuntimeError("не дошёл до экрана Image to Video")

def stage_image(src):
    os.makedirs(STAGE, exist_ok=True)
    # копия без EXIF: иначе «дата съёмки» из EXIF ставит её не первой в окне выбора фото
    from PIL import Image, ImageOps
    dst = os.path.join(STAGE, "i2v_%d.jpg" % int(time.time()))
    ImageOps.exif_transpose(Image.open(src)).convert("RGB").save(dst, "JPEG", quality=95)
    os.chmod(dst, 0o664)
    sh("content", "call", "--uri", "content://media", "--method", "scan_file", "--arg", dst)
    return dst

def pick_newest(nodes):
    """В системном выборе фото взять самый новый снимок (первая плитка «Недавние»)."""
    tap(find(nodes, r"Tap to upload image|Change|Replace", "text") or find(nodes, r"^Upload$", "desc"), 3)
    for _ in range(5):
        nodes = dump()
        photos = [n for n in nodes if re.match(r"(Фото|Photo), ", n["desc"])]
        if photos:
            first = min(photos, key=lambda n: (n["b"][1], n["b"][0]))
            log("выбор фото:", first["desc"][:60]); tap(first, 4); return dump()
        time.sleep(1.5)
    raise RuntimeError("не нашёл плитку фото в окне выбора")

def type_prompt(nodes, text):
    if not text.isascii(): raise ValueError("описание — только латиница (input text не вводит кириллицу)")
    f = next((n for n in nodes if n["cls"].endswith("EditText")), None)
    if not f: raise RuntimeError("нет поля описания")
    tap(f, 1)
    sh("input", "keyevent", "KEYCODE_MOVE_END"); sh("input", "keyevent", "--longpress", "KEYCODE_DEL")
    for i in range(0, len(text), 60):  # длинную строку input обрезает — частями
        sh("input", "text", text[i:i + 60].replace(" ", "%s")); time.sleep(0.3)
    if "mInputShown=true" in sh("dumpsys", "input_method"): sh("input", "keyevent", "KEYCODE_BACK"); time.sleep(1)

def generate_button():
    for _ in range(4):
        nodes = dump(); g = find(nodes, r"^Generate Video$")
        if g and g["y"] < 2950: return nodes, g
        swipe_up()
    raise RuntimeError("нет кнопки Generate Video")

def watch(timeout=900):
    """Ждать результат по logcat приложения: DONE путь / FAIL причина."""
    # У клона иной процесс/UID; pidof исходного PKG может выбрать не тот процесс.
    lc = subprocess.Popen(["logcat", "-v", "time", "-T", "1"],
                          stdout=subprocess.PIPE, text=True, env=ENV, errors="replace")
    t0, last = time.time(), None
    try:
        for line in lc.stdout:
            m = re.search(r"Generation progress: (\d+)%", line)
            if m and m.group(1) != last: last = m.group(1); log("PROGRESS %s%%" % last)
            m = re.search(r"Video generation failed: (\S+)", line)
            if m: log("FAIL", m.group(1)); return None, m.group(1)
            m = re.search(r"Scanned (\S+PhotoFluxAI/\S+\.mp4)", line)
            if m: log("DONE", m.group(1)); return m.group(1), None
            if time.time() - t0 > timeout: return None, "timeout"
    finally:
        lc.kill()
    return None, "logcat закрылся"

def main():
    import argparse
    parser = argparse.ArgumentParser(description="I2V через клон Super Clone из app.inf")
    parser.add_argument("img")
    parser.add_argument("prompt")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--out")
    parser.add_argument("--app-inf", type=Path, default=APP_INF)
    parser.add_argument("--clone-name", help="Имя клона из app.inf; по умолчанию последний")
    opts = parser.parse_args()
    img, prompt, dry, out = opts.img, opts.prompt, opts.dry_run, opts.out
    if not os.path.isfile(img): log("нет файла", img); return 1
    staged = None
    try:
        clone = read_clone(opts.app_inf, opts.clone_name)
        for attempt in range(1, RETRIES + 1):
            nodes = open_i2v(clone)
            left = counter(nodes); log("счётчик:", left)
            if left is None: raise RuntimeError("не прочитал счётчик")
            if left <= 0: close_app("лимит 0"); return 3
            staged = staged or stage_image(img)
            nodes = pick_newest(nodes)
            type_prompt(nodes, prompt)
            nodes, g = generate_button()
            sh("screencap", "-p", "/data/local/tmp/i2v_before.png")
            if dry: log("DRY-RUN: дошёл до Generate Video, не нажимаю"); return 0
            log("Generate Video (попытка %d)" % attempt); tap(g, 1)
            path, err = watch()
            if path:
                if out: os.makedirs(out, exist_ok=True); shutil.copy2(path, out); log("скопировано в", out)
                nodes = dump(); left = counter(nodes); log("счётчик после:", left)
                if left is not None and left <= 0: close_app("лимит 0")
                return 0
            log("сбой генерации:", err, "— повтор" if attempt < RETRIES else "— попытки кончились")
            log("Повтор без force-stop других экземпляров")
            time.sleep(20 if err == "upload_failed" else 5)
        return 1
    except Exception as e:
        sh("screencap", "-p", "/data/local/tmp/i2v_err.png")  # снимок экрана для разбора
        if os.path.exists(DUMP): shutil.copyfile(DUMP, "/data/local/tmp/i2v_err.xml")
        log("ОШИБКА:", e, "(снимок /data/local/tmp/i2v_err.png)"); return 1
    finally:
        if staged and os.path.exists(staged):
            os.remove(staged)
            sh("content", "call", "--uri", "content://media", "--method", "scan_file", "--arg", staged)
        sh("input", "keyevent", "KEYCODE_SLEEP")  # тихий режим: экран обратно выключить

if __name__ == "__main__":
    sys.exit(main())
