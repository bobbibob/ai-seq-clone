#!/usr/bin/env python3
"""Create one AI Image Generator clone via Super Clone UI and append metadata to app.inf."""
import datetime as dt
import json
import re
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

SUPER = 'com.polestar.super.clone'
TARGET = 'com.technosub.unlimitedaiimagen'
OUT = Path(__file__).with_name('app.inf')


def adb(*args, timeout=35):
    p = subprocess.run(['adb', *args], text=True, capture_output=True, timeout=timeout)
    if p.returncode:
        raise RuntimeError(f"adb {' '.join(args)}: {p.stderr.strip() or p.stdout.strip()}")
    return p.stdout


def dump():
    adb('shell', 'uiautomator', 'dump', '/sdcard/sc_automation.xml', timeout=40)
    xml = adb('shell', 'cat', '/sdcard/sc_automation.xml')
    return list(ET.fromstring(xml).iter('node'))


def bounds(node):
    a = [int(x) for x in re.findall(r'\d+', node.get('bounds', ''))]
    if len(a) != 4:
        raise RuntimeError('No valid bounds')
    return (a[0] + a[2]) // 2, (a[1] + a[3]) // 2


def tap(node):
    x, y = bounds(node)
    adb('shell', 'input', 'tap', str(x), str(y))
    time.sleep(1.8)


def find(nodes, *, rid=None, text=None):
    for n in nodes:
        if rid and n.get('resource-id') != rid:
            continue
        if text and n.get('text', '').strip() != text:
            continue
        return n
    return None


def task_dump():
    return adb('shell', 'dumpsys', 'activity', 'activities', timeout=25)


def home_task_id(s):
    for m in re.finditer(r'\* Hist\s+#\d+: ActivityRecord\{[^\n]*\b' + re.escape(SUPER) + r'/[^\s}]*HomeActivity\s+t(\d+)\}', s):
        return int(m.group(1))
    # Fallback: task records on other Android versions
    m = re.search(re.escape(SUPER) + r'/[^\s}]*HomeActivity\s+t(\d+)\}', s)
    return int(m.group(1)) if m else None


def clone_tasks(s):
    found = {}
    for activity, task in re.findall(re.escape(SUPER) + r'/(com\.polestar\.clone\.client\.stub\.StubActivity\$C\d+)\s+t(\d+)', s):
        found[int(task)] = activity
    return found


def clone_labels(nodes):
    return sorted({n.get('text', '').strip() for n in nodes if re.fullmatch(r'AI Image Generator(?:\s*\+|\s*\d+)?', n.get('text', '').strip())})


def delete_old_clones(home, keep_name, old_names):
    """Delete only verified old AI Image Generator clones; abort on ambiguous UI."""
    if not old_names:
        print('No older clones to remove.')
        return []
    adb('shell', 'am', 'task', 'focus', str(home))
    time.sleep(1.5)
    nodes = dump()
    present = clone_labels(nodes)
    if keep_name not in present or not set(old_names).issubset(present):
        raise RuntimeError('Clone list changed; deletion cancelled.')

    # The trash button is available on the Super Clone home screen.
    trash = next((n for n in nodes if re.search(r'(delete|remove|trash)', n.get('resource-id',''), re.I)
                  and n.get('clickable') == 'true'), None)
    if trash is None:
        raise RuntimeError('Cannot identify the trash button safely; older clones were NOT deleted.')
    tap(trash)
    nodes = dump()
    # In selection mode, old labels must still be visible and clickable, or have a clickable parent.
    parent = {child: par for par in nodes for child in par}
    for name in old_names:
        matches = [n for n in nodes if n.get('text', '').strip() == name]
        if len(matches) != 1:
            raise RuntimeError('Cannot uniquely select old clone %r; deletion cancelled.' % name)
        node = matches[0]
        while node is not None and node.get('clickable') != 'true':
            node = parent.get(node)
        if node is None:
            raise RuntimeError('Old clone %r is not selectable; deletion cancelled.' % name)
        tap(node)
        nodes = dump()
        parent = {child: par for par in nodes for child in par}
    # Do not press an unverified confirmation button: different Super Clone
    # versions may use the same icon for entering selection mode and deleting.
    raise RuntimeError('Old clones selected, but delete confirmation UI is unverified. '
                       'No final deletion was submitted; inspect the screen.')


def main():
    print(adb('devices').strip())
    state = task_dump()
    home = home_task_id(state)
    if home is None:
        raise RuntimeError('Super Clone HomeActivity not found. Open Super Clone on the phone first.')
    before_tasks = clone_tasks(state)
    adb('shell', 'am', 'task', 'focus', str(home))
    time.sleep(2)
    nodes = dump()
    before_names = clone_labels(nodes)
    add = find(nodes, rid=SUPER + ':id/addApp_btn')
    if add is None:
        raise RuntimeError('Add-app button not found; verify Super Clone home screen.')
    tap(add)
    nodes = dump()
    if find(nodes, text='Клонировать приложения') is None:
        raise RuntimeError('Clone selection screen not detected; no clone created.')
    choice = find(nodes, rid=SUPER + ':id/grid_item_app_name', text='AI Image Generator')
    if choice is None:
        raise RuntimeError('AI Image Generator not found in app grid; no clone created.')
    tap(choice)
    nodes = dump()
    ready = next((n.get('text', '') for n in nodes if 'готов.' in n.get('text', '') and 'AI Image Generator' in n.get('text', '')), None)
    if ready is None:
        raise RuntimeError('Clone success message not detected. Check screen manually; do not retry blindly.')
    print('Creation confirmed:', ready)
    # Go back to home. Some versions show an optional quick-switch dialog.
    adb('shell', 'input', 'keyevent', 'KEYCODE_BACK')
    time.sleep(1.5)
    nodes = dump()
    decline = find(nodes, text='Нет, спасибо')
    if decline:
        tap(decline)
        nodes = dump()
    # If Back led somewhere else, focus the existing Home task.
    adb('shell', 'am', 'task', 'focus', str(home))
    time.sleep(1.5)
    nodes = dump()
    after_names = clone_labels(nodes)
    new_names = sorted(set(after_names) - set(before_names))
    new_name = new_names[0] if len(new_names) == 1 else None
    record = {
        'created_at': dt.datetime.now(dt.timezone.utc).isoformat(),
        'clone_name': new_name,
        'original_package': TARGET,
        'host_package': SUPER,
        'creation_message': ready,
        'task_id': None,
        'stub_activity': None,
        'task_status': 'not_started',
        'previous_clone_names': before_names,
        'clone_names_after': after_names,
    }
    if new_name:
        label = find(nodes, text=new_name)
        if label:
            tap(label)
            state = task_dump()
            new_tasks = {k: v for k, v in clone_tasks(state).items() if k not in before_tasks}
            if len(new_tasks) == 1:
                record['task_id'], record['stub_activity'] = next(iter(new_tasks.items()))
                record['task_status'] = 'identified'
            else:
                record['task_status'] = 'unresolved'
    else:
        record['task_status'] = 'clone_name_unresolved'
    with OUT.open('a', encoding='utf-8') as f:
        f.write(json.dumps(record, ensure_ascii=False) + '\n')
    print('Saved:', OUT)
    print(json.dumps(record, ensure_ascii=False, indent=2))
    if not new_name:
        raise RuntimeError('New clone name not verified; deletion skipped.')
    delete_old_clones(home, new_name, before_names)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, subprocess.TimeoutExpired, ET.ParseError) as e:
        print('ERROR:', e, file=sys.stderr)
        sys.exit(1)
