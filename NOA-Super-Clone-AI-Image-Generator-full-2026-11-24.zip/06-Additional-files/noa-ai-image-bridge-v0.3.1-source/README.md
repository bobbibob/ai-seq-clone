# NOA AI Image Bridge v0.3.1 — Android 84.0 adapter, source

**Not a prebuilt or device-validated Magisk module.** This version adds actual calls to the installed app's existing lifecycle ViewModels. It must be built through GitHub Actions and tested on the target Samsung before production use.

## Verified from the supplied APK, DEX and decompiled Java

- Super Clone virtual app activities use :p0–:p100; :x alone is not the target. v0.3 process routing is retained.
- JADX's synthetic `defpackage` is not a runtime package. Exact DEX descriptors: `Lv35;` (filters), `Lo55;` (ViewModelStore, field `a`), `Landroidx/navigation/NavControllerViewModel;` (field `viewModelStores`), `Lj12;` and `Lsm1;` (video and image UI states), `Lhc1;` (models, field `p`).
- Video submission uses `onGenerateClicked()`, which performs the app's own daily-limit, ad, and waiting checks. Image submission uses the same `generateImage()` called by the app's button. No direct lower-level generation call, ad completion callback, token extraction, auth changes, quota reset, or creation of new sessions is implemented.
- The adapter looks only in the target Activity's existing ViewModelStore and its existing navigation stores. It fails if there is no existing VM or if multiple matching instances exist.

## Build and install

Copy the source tree into the existing bridge GitHub repository (including hidden `.github`), and run the workflow `Build NOA AI Image Bridge v0.3.1`. The artifact is `noa-ai-image-bridge-v0.3.1-arm64.zip`. This source ZIP is NOT installable. Install the built ZIP in Magisk and reboot. Open an authorized AI Image Generator clone and its image or video screen manually once to initialize its existing ViewModel. The adapter does not implement navigation between screens.

In Samsung Termux, with Python installed:

```bash
su -c 'cat /data/adb/modules/noa_ai_image_bridge/bin/noa-image.py' > "$HOME/noa-image.py"
chmod 700 "$HOME/noa-image.py"
python3 "$HOME/noa-image.py" processes
python3 "$HOME/noa-image.py" capabilities
```

The CLI selects a PID automatically only if exactly one target app is detected. For multiple running instances, use `--pid PID` before the subcommand. This is a process ID, not a clone ID; mapping to clone IDs is not implemented. No automatic account switching. Input paths must be readable by the app, e.g. a suitable shared storage image. Root permission for the bridge is required and can be granted manually in Magisk.

```bash
python3 ~/noa-image.py filters
python3 ~/noa-image.py models
ALERT=true python3 ~/noa-image.py quota video
python3 ~/noa-image.py video --image /sdcard/Pictures/bag.jpg --prompt 'Camera orbit' --prepare-only
python3 ~/noa-image.py video --image /sdcard/Pictures/bag.jpg --filter minecraft
python3 ~/noa-image.py status video
python3 ~/noa-image.py history --refresh
python3 ~/noa-image.py history
python3 ~/noa-image.py cancel
python3 ~/noa-image.py image --prompt 'Black handbag on a counter' --reference /sdcard/Pictures/bag.jpg
python3 ~/noa-image.py status image
ALERT=true python3 ~/noa-image.py quota image
ALERT=true python3 ~/noa-image.py alert 3
```

For image generation add `--model ID` from the live catalog and optionally `--ratio 9:16` (application may override the ratio when reference images are loaded). Up to four `--reference` arguments. The `--prepare-only` flag never calls generation. Preparation confirms video image URI and prompt or image reference count before submission. One submit call per CLI request, no retry if outcome unknown. The CLI uses a per-PID local file lock for cooperative clients. It cannot prevent a manual UI action or other raw root client changing state concurrently.

## Status and alert

`submitted_to_app:true` means the normal app handler was invoked, NOT that a remote server accepted or finished the job. Check `status`: video returns the real app-reported progress, request ID, queue, result URL, ad/wait flags and error; image returns real batch state and available result fields. The image counter is specifically Fireworks, not all image models. Edit quota is read-only. State/quotas may be cached in the app. An active app screen or manual action may be required if the app requests an ad/unlock or login.

`ALERT=true` enables a separate `alert()` function: actual numeric remaining 0–3 adds an alert JSON object to status/quota/submission responses; unknown is never interpreted as zero. The explicit `alert N` command can also test the function. The alert is returned synchronously to the caller, not pushed as a background notification; repeated queries can return the same alert.

## Validation and limits

`bash tests/test.sh` passes shell checks, alert threshold tests, source routing checks, and five mocked Python tests covering selection ambiguity, preparation, submission and dry-run. Those are host tests, not an Android integration test. No Android build was executed locally. CI compiles Java/D8 and ARM64 via NDK, and packages a Magisk archive. Runtime classloader discovery, ViewModel access, file loading, ads, remote generation, results, and actual quota accuracy still need device testing. Automatic clone-ID mapping, all editor features, a dedicated file downloader, push alert delivery and persistent job tracking are not implemented. Do not call this production-ready until tested on device.
