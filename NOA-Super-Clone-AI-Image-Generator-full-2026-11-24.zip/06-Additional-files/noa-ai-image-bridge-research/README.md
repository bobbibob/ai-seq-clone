# NOA AI Image Bridge — research sources, NOT an installable Magisk module

This archive contains the 224 JADX-selected Java sources supplied by the user and a repeatable local analysis script. It does **not** contain a functioning Zygisk module, executable `ai-image` CLI, or GitHub Actions build: the relevant application APIs, runtime entry points, and clone-specific class loaders have not been validated.

## Target

- App: `com.technosub.unlimitedaiimagen`, version 84.0, running as virtual clones in Super Clone.
- Separate module ID when implemented: `noa_ai_image_bridge`.
- Keep the existing `noa_clone_bridge` untouched.

## Required features before claiming implementation

- Discover all application-supported image/video modes, models, parameters, and filter IDs (including server-delivered catalog).
- Trigger generation using normal app authorization and checks, with per-clone routing.
- Report actual job progress, status, output, errors, cancellation where supported.
- Read actual remaining-generation quotas per model/account; alert when remaining < 3; report unknown when unavailable.
- Root-only authenticated IPC, timeouts, idempotency, log/audit events; avoid reliance on UI taps.
- Handle Android process freezing and restarts safely.

## Research

Run `tools/analyze.sh` to produce line-based symbol matches in `analysis/`. These are search results, **not** confirmed callable APIs. Full app code and runtime observations are needed before building the real bridge.
