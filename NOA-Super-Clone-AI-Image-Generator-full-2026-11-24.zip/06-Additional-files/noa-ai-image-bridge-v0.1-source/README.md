# NOA AI Image Bridge v0.1 — installable classloader probe

This is an **initial working implementation of the Zygisk transport and live classloader/filter probe**, not a finished generation bridge. It does **not** generate images or videos, report real progress, or alert on quota. Do not claim those features work.

## Build (GitHub Actions only)

Push all files (including `.github/workflows/build.yml`) to a GitHub repository, then run the workflow **Build NOA AI Image Bridge v0.1**. Download the artifact and install the contained ZIP in Magisk, reboot. It is a separate module ID `noa_ai_image_bridge` and does not modify `noa_clone_bridge`.

## Commands on Samsung

```sh
su -c '/data/adb/modules/noa_ai_image_bridge/bin/ai-image ping'
su -c '/data/adb/modules/noa_ai_image_bridge/bin/ai-image probe'
su -c '/data/adb/modules/noa_ai_image_bridge/bin/ai-image filters'
su -c '/data/adb/modules/noa_ai_image_bridge/bin/ai-image status'
```

The target `com.polestar.super.clone:x` must be running and unfrozen. If frozen, unfreeze it with `cmd activity unfreeze PID` as already tested. The socket only accepts root UID. `probe` reports which classloaders are visible to the bridge, and whether they resolve image/video ViewModels and the filter enum. `filters` enumerates the actual app enum **only when accessible**; otherwise returns a clear error. This distinguishes classloader access from a guess. A successful `ping` only verifies socket/DEX loading.

## Next engineering work

Access virtual app classloader even if not installed as a thread context loader; identify clone IDs, obtain live ViewModel/repository instances without changing application entitlement/ads logic, implement safe command dispatch, asynchronous real progress and quota notifications. The app's coroutines are not safe to call blindly. `ImageToVideoViewModel.generateVideo()` is private and requires initialized UI state. The native API secrets must remain inside the app.

The GitHub workflow uses the official Zygisk header and Android SDK/NDK available on GitHub-hosted runners. No local Termux compilation.
