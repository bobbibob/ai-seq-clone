# NOA AI Image Bridge 0.3 — preview (source)

**Not a complete generation bridge and not a tested installable Magisk build.**

## Verified from the supplied APKs and v0.2 source

Super Clone declares BinderProvider and DaemonService in `:x`, and virtual activity/provider/service stubs in `:p0`–`:p99` (`:p100` also appears). v0.2 targeted only `:x`. The AI Image Generator manifest does not declare an exported generation service. Its ViewModels are internal app classes, not a documented external generation API.

## Changes

- Target virtual process slots, not the manager `:x`.
- Per-PID root-only sockets; client checks peer PID and requires explicit PID when multiple bridges exist.
- Search current application, ActivityThread application/package/activity records, thread context loaders and their parents. Android hidden API restrictions can prevent some discovery; warnings returned by probe.
- Live enum filters only when the relevant classloader is available. No fabricated result.
- Version reporting corrected. Magisk installer sets executable permissions.
- Separate `ALERT=true ... alert N`, threshold 3 inclusive. This consumes a supplied value, NOT live quota; unknown input emits nothing. No repeated-alert suppression or automatic quota collection in this preview.
- CI tests alert boundaries and compiles/packages through GitHub Actions.

## Build

Push the archive contents (including `.github`) into the existing bridge repository and run the GitHub Actions workflow. The workflow produces `noa-ai-image-bridge-v0.3-arm64.zip`. Do not install this source ZIP. Reboot after installing the built module. No Android build has been run in this environment.

## Commands after successful build and installation

Open the authorized AI Image Generator clone manually. Then run in Samsung Termux:

```bash
su -c '/data/adb/modules/noa_ai_image_bridge/bin/ai-image processes'
su -c '/data/adb/modules/noa_ai_image_bridge/bin/ai-image probe --pid PID'
su -c '/data/adb/modules/noa_ai_image_bridge/bin/ai-image filters --pid PID'
```

Use the PID from `processes`, not a clone ID. The process-to-clone mapping has not been established; automatic selection by clone ID is not implemented. The wrapper also unfreezes Super Clone processes before requests.

```bash
ALERT=true bash ai-image.sh alert 3
```

## Not implemented or verified

Generation, reference uploads, model selection, live quota, progress, history, download, cancellation, automatic alert delivery, clone-ID mapping. These are not represented as working commands. No token extraction, quota reset, ad bypass or session manipulation. End-to-end device testing is still required.
