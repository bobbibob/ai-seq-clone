# NOA Clone Bridge v0.1 — probe

This is **source code**, not a compiled Magisk module. Build with GitHub Actions (`workflow_dispatch`).

## Scope
- Loads only in `com.polestar.super.clone:x`.
- Writes `NOAClone` entries to Android logcat.
- Does not create, remove, or alter clones, databases, preferences, or SELinux.

## Build
Upload the repository contents to a GitHub repository, then run **Build NOA Clone Bridge** in GitHub Actions. Download the artifact and extract `noa-clone-bridge-v0.1-arm64.zip`.

## Install
Install the built ZIP in Magisk > Modules > Install from storage. Reboot.

## Check
After starting Super Clone (screen can be switched off afterward), run from Termux:

```sh
su -c 'logcat -d -s NOAClone:I | tail -30'
```

Expected: `postAppSpecialize: injected into Super Clone :x (probe only)`.

If not present, ensure the process was started after the reboot; do not kill the application while its clones are in use. Verify Magisk's Zygisk setting remains enabled.

## Next version
Add a command channel and internal API calls after verifying injection. Access to Java classes in the app's class loader and service initialization timing must be handled separately.
