# NOA AI Image Bridge v0.2 source

This source adds a real clone selector script (`ai-image.sh`) that reads the existing Clone Bridge `list` response. It does NOT implement image/video generation, status progress, or quota. The existing Zygisk probe remains experimental and unverified.

## On Samsung, no build needed for selector

```bash
cp ai-image.sh "$PREFIX/bin/ai-image-select"
chmod +x "$PREFIX/bin/ai-image-select"
ai-image-select select-clone
ai-image-select select-clone --clone 1
```

The selection uses the **last row** of `noa-clonectl list`, not the last used clone (which the API does not expose). It only invokes the existing Clone Bridge.

To build the Zygisk probe: push the entire project to GitHub and run GitHub Actions. Installing the Magisk ZIP does not make generation work.
